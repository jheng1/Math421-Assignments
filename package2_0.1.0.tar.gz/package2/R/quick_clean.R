#quick_clean function
#
#handles missing data by either removing observations with missing values
#or impute the missing values by the mean/mode of the corresponding columns

quick_clean<- function(data, method){
      imputemv=function(data){
        if (is.numeric(data)){
          data[is.na(data)]=mean(data, na.rm=TRUE)
        } else{
          levels=unique(data)
          data[is.na(data)]=levels[which.max(tabulate(match(data,levels)))]
        }
        return(data)
      }
    if(method=="impute"){
      data=lapply(data,imputemv)
    } else if (method=="remove"){
      data=na.exclude(data)
    } else{
      print("Error on input for method handling missing values")
    }
   return(data)
  }
