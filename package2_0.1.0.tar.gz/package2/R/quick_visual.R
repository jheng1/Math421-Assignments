#quick_visual function
#
#plots charts of all possible pair of variables
#
quick_visual = function(data, task){
  library(ggplot2)
  bar=function(data){
    for (i in 1:ncol(data)){
      if (!is.numeric(data[,i])){
        for(j in 1:ncol(data)){
          if (!is.numeric(data[,j]) &
              j!=i &
              nlevels(data[, i]) < 5
              & nlevels(data[,j]) < 5) {
            chart = ggplot(data)+geom_bar(mapping=aes(x=data[,i],fill=data[,j]),position="dodge")+labs(x=names(data)[i],fill=names(data)[j])
            print(chart)
          }
        }
      }
    }
  }

  dens =function(data){
    for (i in 1:ncol(data)){
      if(is.numeric(data[, i])){
        for (j in 1:ncol(data)){  #or a density curve can be a combination of numeric and categorical
          if(!is.numeric(data[, j]) & nlevels(data[, j]) < 5){
            chart1 = ggplot(data) + geom_density(mapping = aes(x = data[, i], color = data [ , j])) + labs(x = names(data)[i], color = names(data)[j])
            print(chart1)
          }
        }
      }
    }
  }

  point=function(data){
    for (i in 1:ncol(data)){
      if (is.numeric(data[,i])){
        for(j in 1:ncol(data)){
          if (is.numeric(data[,j]) & j!=i){
            chart2 = ggplot(data) + geom_point(mapping = aes(x=data[, i], y = data[, j])) + labs(x = names(data[i]), y = names(data[j]))
            print(chart2)
          }
        }
      }
    }
  }

  if(task == "1"){
    bar(data)
  }
  else if(task == "2"){
    dens(data)
  }
  else if (task == "3"){
    point(data)
  }else {
    print("Please type in task number: 1 - bar; 2 - density ; 3 - scatter plot")
  }

}
