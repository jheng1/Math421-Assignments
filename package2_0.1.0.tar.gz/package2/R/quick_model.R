#quick_model function
#build a random forest using ranger package and output the accuracy
#input includes data frame and target variable named "target"

titanic=read.csv("C:/Users/student/Downloads/R/titanic.csv")
names(titanic)=c('PassengerId', 'target', 'Pclass', 'Name', 'Sex', 'Age', 'SibSp', 'Parch', 'Ticket', 'Fare', 'Cabin', 'Embarked')

quick_model<-function(data){
  library(ranger)
  library(caret)
  myGrid = expand.grid(mtry = 3, splitrule = c("gini"), min.node.size = c(1:3))
  preProcess_missingdata_model <- preProcess(data, method='medianImpute')
  model <- train(
    target~.,
    tuneLength = 1,
    data = data, method = "ranger",
    trControl = trainControl(method = "cv", number = 4, verboseIter = TRUE),tuneGrid=myGrid)
  pred  = predict(model, data)
  levels(data$target) = c("0", "1")
  levels(pred) = c("0", "1")
  cm=confusionMatrix(pred, data$target, positive="1")
  print(cm)
}



